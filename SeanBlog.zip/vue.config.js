const path = require('path');
const SkeletonWebpackPlugin = require('vue-skeleton-webpack-plugin');
const VueSSRServerPlugin = require("vue-server-renderer/server-plugin");
const VueSSRClientPlugin = require("vue-server-renderer/client-plugin");
const nodeExternals = require("webpack-node-externals");
const merge = require("lodash.merge");
const TARGET_NODE = process.env.WEBPACK_TARGET === "node";
const target = TARGET_NODE ? "server" : "client";
const isDev = process.env.NODE_ENV !== 'production'

module.exports = {
    // 项目部署的基础路径 /
    publicPath: isDev ? 'http://127.0.0.1:8080' : 'http://127.0.0.1:3000',

    // 将构建好的文件输出到哪里
    outputDir: process.env.outputDir,

    assetsDir: 'static',

    css: {
        extract: process.env.NODE_ENV === 'production', // 是否使用css分离插件 ExtractTextPlugin
        sourceMap: false, // 开启 CSS source maps?
        loaderOptions: {
            // css moudle 配置：https://www.jianshu.com/p/125f33c35446
            css: {
                localIdentName: '[name]__[local]-[hash:base64:5]',
                camelCase: true
            },

            sass: {
                // 给 sass-loader 传递选项，@/ 是 src/ 的别名，引入相对路径
            },
            less: {
                javascriptEnabled: true
            }
        }, // css预设器配置项
        modules: false // 启用 CSS modules for all css / pre-processor files.
    },

    lintOnSave: false,

    // 配置 webpack-dev-server 行为。
    devServer: {
        historyApiFallback: true,
        headers: {'Access-Control-Allow-Origin': '*'},
        compress: true, //一切服务都启用 gzip 压缩
        host: '0.0.0.0',
        // host: '192.168.0.164',
        port: 8080,
        https: false,
        hotOnly: false,
        open: true,
        // 查阅 https://github.com/vuejs/vue-docs-zh-cn/blob/master/vue-cli/cli-service.md#配置代理
        // proxy: 'http://localhost:3001', // string | Object
        proxy: {
            '/api': {
                // 目标 API 地址
                target: 'http://127.0.0.1/myself/SeanBlogPhp/public/',
                ws: true,
                changeOrigin: true,
                pathRewrite: {
                    '^/api': '/'
                }
            }
        },
        // before: app => {}
    },

    chainWebpack: config => {
        /**
         * 删除懒加载模块的prefetch，降低带宽压力
         * https://cli.vuejs.org/zh/guide/html-and-static-assets.html#prefetch
         * 而且预渲染时生成的prefetch标签是modern版本的，低版本浏览器是不需要的
         */
        config.plugins
            .delete('prefetch');
        config.module
            .rule('images')
            .use('url-loader')
            .loader('url-loader')
            .tap(options => {
                options.limit = 10000;
                return options
            });
        config.module
            .rule("vue")
            .use("vue-loader")
            .tap(options => {
                merge(options, {
                    optimizeSSR: false
                });
            });

        // fix ssr hot update bug
        if (TARGET_NODE) {
            config.plugins.delete("hmr");
        }
    },

    configureWebpack: (config) => ({
        // 将 entry 指向应用程序的 server / client 文件
        entry: `./src/entry-${target}.js`,
        // 对 bundle renderer 提供 source map 支持
        devtool: 'source-map',
        target: TARGET_NODE ? "node" : "web",
        node: TARGET_NODE ? undefined : false,
        output: {
            libraryTarget: TARGET_NODE ? "commonjs2" : undefined
        },
        // https://webpack.js.org/configuration/externals/#function
        // https://github.com/liady/webpack-node-externals
        // 外置化应用程序依赖模块。可以使服务器构建速度更快，
        // 并生成较小的 bundle 文件。
        externals: TARGET_NODE
            ? nodeExternals({
                // 不要外置化 webpack 需要处理的依赖模块。
                // 你可以在这里添加更多的文件类型。例如，未处理 *.vue 原始文件，
                // 你还应该将修改 `global`（例如 polyfill）的依赖模块列入白名单
                whitelist: [/\.css$/]
            })
            : undefined,
        optimization: {
            splitChunks: undefined
        },
        // vue骨架屏插件配置
        plugins: [
            TARGET_NODE ? new VueSSRServerPlugin() : new VueSSRClientPlugin(),
            new SkeletonWebpackPlugin({
                webpackConfig: {
                    entry: {
                        app: path.join(__dirname, './src/config/skeleton.js'),
                    },
                },
                minimize: true,
                quiet: true,
            })]
    }),

    // 第三方插件的选项
    pluginOptions: {},

    runtimeCompiler: false,
    productionSourceMap: false,
    parallel: undefined,

    pwa: {
        name: 'Sean Blog',
        themeColor: '#F04848',
        msTileColor: '#000000',
        appleMobileWebAppCapable: 'yes',
        appleMobileWebAppStatusBarStyle: 'black',
        /*
        * 两个模式，GenerateSW（默认）和 InjectManifest
        * GenerateSW 在我们build项目时候，每次都会新建一个service worker文件
        * InjectManifest 可以让我们编辑一个自定义的service worker文件，实现更多的功能，并且可以
        * 拿到预缓存列表
        */
        workboxPluginMode: 'InjectManifest',
        workboxOptions: {
            // 自定义的service worker文件的位置
            swSrc: 'service-worker.js',
            // ...other Workbox options...
        }
    }
};

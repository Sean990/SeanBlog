<template>
    <div>
        <keep-alive>
            <app-header></app-header>
        </keep-alive>
        <router-view></router-view>
        <keep-alive>
            <app-footer></app-footer>
        </keep-alive>
        <alert :status="'success'" :msg="'hahahahhaha'"></alert>
    </div>
</template>

<script>
    import AppHeader from '@/components/Header'
    import AppFooter from '@/components/Footer'
    import Alert from '@/components/Alert'

    export default {
        data() {
            return {}
        },
        components: {AppHeader, AppFooter, Alert},
        methods: {}
    }
</script>

<style lang="scss">
    @import './style/base/_base.scss';
</style>
